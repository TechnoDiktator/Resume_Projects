package com.tarang.blog.exceptions;

public class ApiException extends RuntimeException {

	public ApiException(String message) {
		
		
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ApiException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	

}
