package com.tarang.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.tarang.blog.repositories.UserRepo;

@SpringBootTest
class ApplicationTests {

	@Test
	void contextLoads() {
	}
	
	
	
	
	
	@Test
	public void repoTest() {
		

	}

}
